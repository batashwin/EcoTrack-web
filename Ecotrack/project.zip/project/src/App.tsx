import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import EWasteTracker from './pages/EWasteTracker';
import AIAssessment from './pages/AIAssessment';
import RewardsProgram from './pages/RewardsProgram';
import PickupService from './pages/PickupService';
import KnowledgeHub from './pages/KnowledgeHub';
import LoadingScreen from './components/LoadingScreen';
import { AuthProvider } from './context/AuthContext';

function App() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading time
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-gradient-to-b from-green-50 to-white">
          <Navbar />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/tracker" element={<EWasteTracker />} />
            <Route path="/ai-assessment" element={<AIAssessment />} />
            <Route path="/rewards" element={<RewardsProgram />} />
            <Route path="/pickup" element={<PickupService />} />
            <Route path="/knowledge" element={<KnowledgeHub />} />
          </Routes>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;