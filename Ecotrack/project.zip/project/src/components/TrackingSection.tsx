import React, { useState } from 'react';
import { Upload, AlertCircle, CheckCircle } from 'lucide-react';

const TrackingSection = () => {
  const [deviceType, setDeviceType] = useState('');
  const [condition, setCondition] = useState('');
  const [age, setAge] = useState('');
  const [recommendation, setRecommendation] = useState('');
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [aiPrediction, setAiPrediction] = useState('');

  const deviceTypes = ['Smartphone', 'Laptop', 'Tablet', 'Desktop Computer', 'Printer', 'Other'];
  const conditions = ['Like New', 'Good', 'Fair', 'Poor', 'Not Working'];
  const ageRanges = ['Less than 1 year', '1-2 years', '2-3 years', '3-5 years', 'More than 5 years'];

  const handleDeviceSubmit = (e) => {
    e.preventDefault();
    // Simulate recommendation logic
    let recommendation = '';
    if (condition === 'Like New' || condition === 'Good') {
      recommendation = 'Your device is in good condition! Consider donating it to local schools or charities.';
    } else if (condition === 'Fair') {
      recommendation = 'Your device could be refurbished. We recommend visiting our certified repair partners.';
    } else {
      recommendation = 'This device should be recycled. We\'ll connect you with certified recycling centers.';
    }
    setRecommendation(recommendation);
  };

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    setSelectedFiles(files);
    // Simulate AI analysis
    setTimeout(() => {
      setAiPrediction('Based on the images, this device appears suitable for refurbishment. We estimate 80% of components can be reused or recycled.');
    }, 1500);
  };

  return (
    <div className="py-12 bg-green-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center mb-12 animate-fade-in">
          <h2 className="text-base text-green-600 font-semibold tracking-wide uppercase">
            Start Tracking
          </h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            Register Your Device
          </p>
        </div>

        <div className="max-w-xl mx-auto">
          <form onSubmit={handleDeviceSubmit} className="space-y-6 bg-white p-8 rounded-lg shadow-lg transform hover:scale-[1.01] transition-all duration-300">
            <div>
              <label htmlFor="deviceType" className="block text-sm font-medium text-gray-700">
                Device Type
              </label>
              <select
                id="deviceType"
                value={deviceType}
                onChange={(e) => setDeviceType(e.target.value)}
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm rounded-md"
              >
                <option value="">Select a device type</option>
                {deviceTypes.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="age" className="block text-sm font-medium text-gray-700">
                Device Age
              </label>
              <select
                id="age"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm rounded-md"
              >
                <option value="">Select device age</option>
                {ageRanges.map((range) => (
                  <option key={range} value={range}>
                    {range}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="condition" className="block text-sm font-medium text-gray-700">
                Device Condition
              </label>
              <select
                id="condition"
                value={condition}
                onChange={(e) => setCondition(e.target.value)}
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm rounded-md"
              >
                <option value="">Select condition</option>
                {conditions.map((cond) => (
                  <option key={cond} value={cond}>
                    {cond}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Upload Device Images
              </label>
              <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md hover:border-green-500 transition-colors">
                <div className="space-y-1 text-center">
                  <Upload className="mx-auto h-12 w-12 text-gray-400" />
                  <div className="flex text-sm text-gray-600">
                    <label
                      htmlFor="file-upload"
                      className="relative cursor-pointer bg-white rounded-md font-medium text-green-600 hover:text-green-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-green-500"
                    >
                      <span>Upload files</span>
                      <input
                        id="file-upload"
                        name="file-upload"
                        type="file"
                        className="sr-only"
                        multiple
                        onChange={handleFileChange}
                      />
                    </label>
                    <p className="pl-1">or drag and drop</p>
                  </div>
                  <p className="text-xs text-gray-500">PNG, JPG, GIF up to 10MB</p>
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transform hover:scale-105 transition-all duration-300"
            >
              Analyze Device
            </button>
          </form>

          {recommendation && (
            <div className="mt-6 p-4 bg-white rounded-lg shadow-lg animate-fade-in">
              <div className="flex items-start">
                <CheckCircle className="h-6 w-6 text-green-500 mt-1" />
                <div className="ml-3">
                  <h3 className="text-lg font-medium text-gray-900">Recommendation</h3>
                  <p className="mt-2 text-gray-600">{recommendation}</p>
                </div>
              </div>
            </div>
          )}

          {aiPrediction && (
            <div className="mt-6 p-4 bg-white rounded-lg shadow-lg animate-fade-in">
              <div className="flex items-start">
                <AlertCircle className="h-6 w-6 text-blue-500 mt-1" />
                <div className="ml-3">
                  <h3 className="text-lg font-medium text-gray-900">AI Analysis</h3>
                  <p className="mt-2 text-gray-600">{aiPrediction}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TrackingSection;