import React from 'react';
import { Recycle } from 'lucide-react';

const LoadingScreen = () => {
  return (
    <div className="fixed inset-0 bg-white z-50 flex items-center justify-center">
      <div className="text-center">
        <Recycle className="h-16 w-16 text-green-600 animate-spin mx-auto" />
        <h2 className="mt-4 text-xl font-semibold text-gray-900">EcoTrack</h2>
        <p className="mt-2 text-gray-600">Loading your sustainable future...</p>
      </div>
    </div>
  );
};

export default LoadingScreen;