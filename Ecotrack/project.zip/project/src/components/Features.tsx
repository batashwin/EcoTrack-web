import React from 'react';
import { Link } from 'react-router-dom';
import { Recycle, Upload, Gift, Truck, BookOpen, ShoppingBag, DollarSign } from 'lucide-react';

const features = [
  {
    name: 'E-Waste Tracker',
    description: 'Input your old electronics and get personalized disposal recommendations.',
    icon: Recycle,
    link: '/tracker'
  },
  {
    name: 'AI Assessment',
    description: 'Upload device images for instant condition analysis and recycling suggestions.',
    icon: Upload,
    link: '/ai-assessment'
  },
  {
    name: 'Rewards Program',
    description: 'Earn points for responsible disposal and redeem them for eco-friendly products.',
    icon: Gift,
    link: '/rewards'
  },
  {
    name: 'Pickup Service',
    description: 'Schedule convenient doorstep pickup for your electronic waste.',
    icon: Truck,
    link: '/pickup'
  },
  {
    name: 'Knowledge Hub',
    description: 'Stay informed with the latest e-waste management trends and tips.',
    icon: BookOpen,
    link: '/knowledge'
  },
  {
    name: 'Buy Refurbished Devices',
    description: 'Shop quality refurbished electronics at great prices.',
    icon: ShoppingBag,
    link: '/buy-refurbished'
  },
  {
    name: 'Sell Your Old Device',
    description: 'Get the best value for your used electronics.',
    icon: DollarSign,
    link: '/sell-device'
  }
];

const Features = () => {
  return (
    <div className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center">
          <h2 className="text-base text-green-600 font-semibold tracking-wide uppercase">Features</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            Smart E-Waste Management
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
            Transform your approach to electronic waste with our comprehensive suite of tools and services.
          </p>
        </div>

        <div className="mt-10">
          <dl className="space-y-10 md:space-y-0 md:grid md:grid-cols-2 lg:grid-cols-3 md:gap-x-8 md:gap-y-10">
            {features.map((feature) => (
              <Link
                key={feature.name}
                to={feature.link}
                className="relative group hover:transform hover:scale-105 transition-all duration-200"
              >
                <dt>
                  <div className="absolute flex items-center justify-center h-12 w-12 rounded-md bg-green-500 text-white group-hover:bg-green-600 transition-colors">
                    <feature.icon className="h-6 w-6" aria-hidden="true" />
                  </div>
                  <p className="ml-16 text-lg leading-6 font-medium text-gray-900">{feature.name}</p>
                </dt>
                <dd className="mt-2 ml-16 text-base text-gray-500">{feature.description}</dd>
              </Link>
            ))}
          </dl>
        </div>
      </div>
    </div>
  );
};

export default Features;