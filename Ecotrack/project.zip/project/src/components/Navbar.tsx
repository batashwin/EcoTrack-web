import React from 'react';
import { Link } from 'react-router-dom';
import { BatteryCharging } from 'lucide-react';

const Navbar = () => {
  return (
    <nav className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <Link to="/" className="flex items-center">
            <BatteryCharging className="h-8 w-8 text-green-600" />
            <span className="ml-2 text-xl font-bold text-gray-900">EcoTrack</span>
          </Link>
          <div className="hidden md:flex items-center space-x-8">
            <Link to="/tracker" className="text-gray-600 hover:text-green-600">E-Waste Tracker</Link>
            <Link to="/ai-assessment" className="text-gray-600 hover:text-green-600">AI Assessment</Link>
            <Link to="/rewards" className="text-gray-600 hover:text-green-600">Rewards</Link>
            <Link to="/pickup" className="text-gray-600 hover:text-green-600">Pickup</Link>
            <Link to="/knowledge" className="text-gray-600 hover:text-green-600">Knowledge Hub</Link>
            <Link
              to="/tracker"
              className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors"
            >
              Get Started
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;