import React from 'react';
import { Mail, Phone, MapPin, Instagram, Facebook, Twitter, Youtube } from 'lucide-react';

const Contact = () => {
  return (
    <div id="contact" className="bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 animate-fade-in">
          <h2 className="text-3xl font-bold text-gray-900">Contact Us</h2>
          <p className="mt-4 text-lg text-gray-600">Get in touch with our team for any inquiries</p>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-8 max-w-4xl mx-auto transform hover:scale-[1.02] transition-all duration-300">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="space-y-8 animate-fade-in" style={{ animationDelay: '200ms' }}>
              <h3 className="text-xl font-semibold text-gray-900 border-b pb-2">Contact Information</h3>
              <div className="space-y-6">
                <div className="flex items-center space-x-4 transform hover:translate-x-2 transition-transform">
                  <Mail className="h-6 w-6 text-green-600" />
                  <a href="mailto:contact@ecotrack.com" className="text-gray-600 hover:text-green-600 text-lg">
                    contact@ecotrack.com
                  </a>
                </div>
                <div className="flex items-center space-x-4 transform hover:translate-x-2 transition-transform">
                  <Phone className="h-6 w-6 text-green-600" />
                  <a href="tel:+1234567890" className="text-gray-600 hover:text-green-600 text-lg">
                    (123) 456-7890
                  </a>
                </div>
                <div className="flex items-center space-x-4 transform hover:translate-x-2 transition-transform">
                  <MapPin className="h-6 w-6 text-green-600" />
                  <span className="text-gray-600 text-lg">
                    123 Green Street, Eco City, EC 12345
                  </span>
                </div>
              </div>
            </div>

            <div className="space-y-8 animate-fade-in" style={{ animationDelay: '400ms' }}>
              <h3 className="text-xl font-semibold text-gray-900 border-b pb-2">Connect With Us</h3>
              <div className="grid grid-cols-2 gap-6">
                <a
                  href="https://instagram.com/ecotrack"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-3 p-4 rounded-lg bg-gray-50 hover:bg-green-50 transform hover:scale-105 transition-all duration-300"
                >
                  <Instagram className="h-6 w-6 text-green-600" />
                  <span className="text-gray-600">Instagram</span>
                </a>
                <a
                  href="https://facebook.com/ecotrack"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-3 p-4 rounded-lg bg-gray-50 hover:bg-green-50 transform hover:scale-105 transition-all duration-300"
                >
                  <Facebook className="h-6 w-6 text-green-600" />
                  <span className="text-gray-600">Facebook</span>
                </a>
                <a
                  href="https://twitter.com/ecotrack"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-3 p-4 rounded-lg bg-gray-50 hover:bg-green-50 transform hover:scale-105 transition-all duration-300"
                >
                  <Twitter className="h-6 w-6 text-green-600" />
                  <span className="text-gray-600">Twitter</span>
                </a>
                <a
                  href="https://youtube.com/ecotrack"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-3 p-4 rounded-lg bg-gray-50 hover:bg-green-50 transform hover:scale-105 transition-all duration-300"
                >
                  <Youtube className="h-6 w-6 text-green-600" />
                  <span className="text-gray-600">YouTube</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;