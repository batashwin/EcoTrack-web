import React from 'react';
import Hero from '../components/Hero';
import Features from '../components/Features';
import TrackingSection from '../components/TrackingSection';
import Reviews from '../components/Reviews';
import Contact from '../components/Contact';

const Home = () => {
  return (
    <>
      <Hero />
      <Features />
      <TrackingSection />
      <Reviews />
      <Contact />
    </>
  );
};

export default Home;