import React from 'react';
import { BookOpen, Clock, User, ThumbsUp } from 'lucide-react';

const KnowledgeHub = () => {
  const articles = [
    {
      title: "The Impact of E-Waste on Our Environment",
      description: "Learn about the environmental consequences of electronic waste and why proper disposal matters.",
      image: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      author: "Dr. Sarah Green",
      readTime: "5 min read",
      likes: 234
    },
    {
      title: "Best Practices for Electronics Recycling",
      description: "Discover the most effective methods for recycling your electronic devices responsibly.",
      image: "https://images.unsplash.com/photo-1567177662154-805d27f7e7c8?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      author: "Mike Johnson",
      readTime: "8 min read",
      likes: 156
    },
    {
      title: "The Future of Sustainable Technology",
      description: "Explore upcoming trends in eco-friendly electronics and sustainable manufacturing.",
      image: "https://images.unsplash.com/photo-1605600659876-719322829ffe?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      author: "Tech Sustainability Team",
      readTime: "10 min read",
      likes: 189
    },
    {
      title: "From E-Waste to Resources",
      description: "How recycled electronics are transformed into valuable materials for new products.",
      image: "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      author: "Emily Chen",
      readTime: "7 min read",
      likes: 145
    },
    {
      title: "Guide to Device Longevity",
      description: "Tips and tricks to extend the life of your electronic devices and reduce e-waste.",
      image: "https://images.unsplash.com/photo-1498049794561-7780e7231661?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      author: "Tech Care Expert",
      readTime: "6 min read",
      likes: 201
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-bold text-gray-900 mb-8 animate-fade-in">Knowledge Hub</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {articles.map((article, index) => (
          <div 
            key={index} 
            className="bg-white rounded-lg shadow-lg overflow-hidden transform hover:scale-105 transition-all duration-300 animate-fade-in"
            style={{ animationDelay: `${index * 100}ms` }}
          >
            <img src={article.image} alt={article.title} className="w-full h-48 object-cover" />
            <div className="p-6">
              <h3 className="text-xl font-semibold mb-2">{article.title}</h3>
              <p className="text-gray-600 mb-4">{article.description}</p>
              <div className="flex items-center text-sm text-gray-500 space-x-4">
                <div className="flex items-center">
                  <User className="h-4 w-4 mr-1" />
                  <span>{article.author}</span>
                </div>
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-1" />
                  <span>{article.readTime}</span>
                </div>
                <div className="flex items-center">
                  <ThumbsUp className="h-4 w-4 mr-1" />
                  <span>{article.likes}</span>
                </div>
              </div>
              <button className="mt-4 text-green-600 hover:text-green-700 font-medium transition-colors">
                Read More →
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default KnowledgeHub;