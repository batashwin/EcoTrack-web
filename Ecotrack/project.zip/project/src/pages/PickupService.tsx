import React, { useState } from 'react';
import { Truck, MapPin } from 'lucide-react';

const recyclingCenters = {
  'United States': {
    'California': {
      'San Francisco': [
        { name: 'SF Recycling Center', address: '123 Green St', rating: 4.5 },
        { name: 'Bay Area E-Waste', address: '456 Eco Ave', rating: 4.8 }
      ],
      'Los Angeles': [
        { name: 'LA Electronics Recycling', address: '789 Tech Blvd', rating: 4.3 },
        { name: 'SoCal E-Waste Solutions', address: '321 Digital Dr', rating: 4.6 }
      ]
    },
    'New York': {
      'New York City': [
        { name: 'NYC E-Cycle', address: '567 Broadway', rating: 4.7 },
        { name: 'Manhattan Recycling', address: '890 5th Ave', rating: 4.4 }
      ]
    }
  },
  'Canada': {
    'Ontario': {
      'Toronto': [
        { name: 'Toronto Tech Recycling', address: '123 Queen St', rating: 4.6 },
        { name: 'GTA E-Waste Solutions', address: '456 King St', rating: 4.5 }
      ]
    }
  }
};

const PickupService = () => {
  const [country, setCountry] = useState('');
  const [state, setState] = useState('');
  const [city, setCity] = useState('');
  const [centers, setCenters] = useState([]);

  const handleLocationChange = () => {
    if (country && state && city && recyclingCenters[country]?.[state]?.[city]) {
      setCenters(recyclingCenters[country][state][city]);
    } else {
      setCenters([]);
    }
  };

  React.useEffect(() => {
    handleLocationChange();
  }, [country, state, city]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Pickup Service</h1>
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center mb-6">
          <Truck className="h-8 w-8 text-green-600" />
          <h2 className="text-xl font-semibold ml-2">Schedule a Pickup</h2>
        </div>
        <form className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700">Full Name</label>
              <input
                type="text"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                placeholder="Enter your full name"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Mobile Number</label>
              <input
                type="tel"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                placeholder="Enter your mobile number"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Country/Region</label>
              <select
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
              >
                <option value="">Select country</option>
                {Object.keys(recyclingCenters).map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">State/Province</label>
              <select
                value={state}
                onChange={(e) => setState(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                disabled={!country}
              >
                <option value="">Select state</option>
                {country && Object.keys(recyclingCenters[country]).map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">City</label>
              <select
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                disabled={!state}
              >
                <option value="">Select city</option>
                {state && Object.keys(recyclingCenters[country][state]).map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Pincode</label>
              <input
                type="text"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                placeholder="Enter pincode"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Flat/House No., Building, Company, Apartment</label>
            <input
              type="text"
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
              placeholder="Enter your detailed address"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Area, Street, Village</label>
            <input
              type="text"
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
              placeholder="Enter area details"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Landmark</label>
            <input
              type="text"
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
              placeholder="Enter a nearby landmark"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Preferred Date</label>
            <input
              type="date"
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors"
          >
            Schedule Pickup
          </button>
        </form>

        {centers.length > 0 && (
          <div className="mt-8">
            <h3 className="text-lg font-semibold mb-4">Nearby Recycling Centers</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {centers.map((center, index) => (
                <div key={index} className="border rounded-lg p-4 hover:shadow-lg transition-shadow">
                  <div className="flex items-start">
                    <MapPin className="h-5 w-5 text-green-600 mt-1" />
                    <div className="ml-3">
                      <h4 className="font-medium">{center.name}</h4>
                      <p className="text-gray-600">{center.address}</p>
                      <div className="mt-2 flex items-center">
                        <span className="text-yellow-500">★</span>
                        <span className="ml-1 text-gray-600">{center.rating}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PickupService;