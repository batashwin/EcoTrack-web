import React from 'react';
import { Gift, Award, Star } from 'lucide-react';

const RewardsProgram = () => {
  const refurbishedDevices = [
    {
      name: "Refurbished iPhone 12",
      points: 15000,
      image: "https://images.unsplash.com/photo-1592286927505-1def25115558?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      description: "Fully restored iPhone 12 with 1-year warranty"
    },
    {
      name: "Eco-Friendly Laptop",
      points: 25000,
      image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      description: "Sustainable laptop made from recycled materials"
    },
    {
      name: "Solar Power Bank",
      points: 5000,
      image: "https://images.unsplash.com/photo-1593784991095-a205069470b6?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      description: "Eco-friendly solar-powered charging bank"
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Rewards Program</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
        <div className="bg-white rounded-lg shadow p-6 transform hover:scale-105 transition-all duration-300">
          <div className="flex items-center mb-4">
            <Gift className="h-8 w-8 text-green-600" />
            <h2 className="text-xl font-semibold ml-2">Your Points</h2>
          </div>
          <div className="text-4xl font-bold text-green-600 animate-pulse">1,250</div>
          <p className="text-gray-600 mt-2">Points available</p>
        </div>
        <div className="bg-white rounded-lg shadow p-6 transform hover:scale-105 transition-all duration-300">
          <div className="flex items-center mb-4">
            <Award className="h-8 w-8 text-green-600" />
            <h2 className="text-xl font-semibold ml-2">Current Tier</h2>
          </div>
          <div className="flex items-center">
            <Star className="h-6 w-6 text-yellow-500" />
            <span className="text-xl font-semibold ml-2">Silver Member</span>
          </div>
          <p className="text-gray-600 mt-2">3,750 points to Gold tier</p>
        </div>
      </div>

      <h2 className="text-2xl font-semibold mb-6">Available Rewards</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {refurbishedDevices.map((device, index) => (
          <div key={index} className="bg-white rounded-lg shadow-lg overflow-hidden transform hover:scale-105 transition-all duration-300">
            <img src={device.image} alt={device.name} className="w-full h-48 object-cover" />
            <div className="p-6">
              <h3 className="text-xl font-semibold mb-2">{device.name}</h3>
              <p className="text-gray-600 mb-4">{device.description}</p>
              <div className="flex justify-between items-center">
                <span className="text-green-600 font-bold">{device.points} points</span>
                <button className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors">
                  Redeem
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RewardsProgram;